The right order of execution:
1) folder '1 -data' -> 'wrds 1day Data' ->data_fix.py
2) optionally -> folder '2- statistic check' -> 'advanced_gap_analysis.py'
								    ->'gap_info_analysis.py'
3) folder '3- catBoost' -> 'examples producing' -> 'catboost_gap_analysis.py'
				   -> 'catboost_year_training.py'
4) folder '4- optimization' -> 'main.py'

# Dont change the names of the folders or its order.
	The python script will not work int this case.
